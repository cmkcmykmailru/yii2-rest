<?php

use Ramsey\Uuid\Uuid;
use yii\db\Migration;

class m170531_084120_create_phones_table extends Migration
{
    public function up()
    {
        $tableOptions = 'CHARACTER SET utf8 COLLATE utf8_unicode_ci ENGINE=InnoDB';

        $this->createTable('{{%phones}}', [
            'id' => $this->string()->notNull()->unique(),
            'phone_number' => $this->string(11)->notNull(),
            'created_at' => $this->integer()->unsigned()->notNull(),
            'updated_at' => $this->integer()->unsigned()->notNull(),
        ], $tableOptions);

        $this->addPrimaryKey('{{%pk-phones}}', '{{%phones}}', ['id']);
        $this->createIndex('{{%idx-phones-phone_number}}', '{{%phones}}', 'phone_number');

        $phone1 = ['f957e6fb-7d31-45de-bbeb-c9fb3e69faad', 7000000000, time(), time(),];
        $phone2 = [Uuid::uuid4()->toString(), 7111111111, time(), time(),];
        $phone3 = [Uuid::uuid4()->toString(), 7222222222, time(), time(),];

        $this->batchInsert('{{%phones}}', ['id', 'phone_number', 'created_at', 'updated_at'], [
            $phone1, $phone2, $phone3,
        ]);
    }

    public function down()
    {
        return false;
    }
}